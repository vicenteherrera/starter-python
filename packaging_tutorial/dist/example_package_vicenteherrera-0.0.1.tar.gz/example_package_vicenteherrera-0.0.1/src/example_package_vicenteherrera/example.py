
# https://packaging.python.org/en/latest/tutorials/packaging-projects/

def add_one(number):
    return number + 1